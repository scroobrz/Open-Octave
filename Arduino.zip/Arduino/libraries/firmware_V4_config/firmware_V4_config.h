#ifndef FIRMWARE_V4_CONFIG_H
#define FIRMWARE_V4_CONFIG_H

#include <Adafruit_NeoPixel.h>
#include <Wire.h>
#include <stdint.h>

#define SERIAL_BUF_SIZE 64

#define WIFI_SSID "Open Octave"
#define WIFI_PASSWORD "oop321321"

// ============ HARDWARE CONFIG ============

#define DEBOUNCE_DELAY 50
#define SERVO_RELEASE_DELAY 120   // ms to wait for servo to physically release

#define MAX_SEQUENCE_LENGTH 64

#define MIN_NOTE_DURATION 100
#define MAX_NOTE_DURATION 10000

#define SERVO_FREQ 50
#define SERVO_REST_ANGLE 0
#define SERVO_PRESS_ANGLE 180
#define SERVO_MIN_SAFE_ANGLE 0
#define SERVO_MAX_SAFE_ANGLE 180

#define NUM_KEYS 12

#define LEDS_PER_KEY 1
#define LED_BRIGHTNESS 50

// Pin assignments
// STRICTLY AVOID On ESP32: IO6-IO11 (SPI flash), IO1/IO3 (UART), IO34-IO39 (input-only)
// RESERVED On ESP32: IO21 (SDA) and IO22 (SCL) for I2C to PCA9685 and PCA9555

#define SPEAKER_PIN 25          // D2 (IO25) — DAC-capable, good for audio

#define KEY0_BUTTON_PIN 0
#define KEY0_LED_PIN 4
#define KEY0_SERVO_CHANNEL 1
#define KEY0_NOTE 262  // C4

#define KEY1_BUTTON_PIN 1
#define KEY1_LED_PIN 13
#define KEY1_SERVO_CHANNEL 2
#define KEY1_NOTE 277  // C#4

#define KEY2_BUTTON_PIN 2
#define KEY2_LED_PIN 14
#define KEY2_SERVO_CHANNEL 3
#define KEY2_NOTE 294  // D4

#define KEY3_BUTTON_PIN 3
#define KEY3_LED_PIN 16
#define KEY3_SERVO_CHANNEL 4
#define KEY3_NOTE 311  // D#4

#define KEY4_BUTTON_PIN 4
#define KEY4_LED_PIN 17
#define KEY4_SERVO_CHANNEL 5
#define KEY4_NOTE 330  // E4

#define KEY5_BUTTON_PIN 5
#define KEY5_LED_PIN 18
#define KEY5_SERVO_CHANNEL 6
#define KEY5_NOTE 349  // F4

#define KEY6_BUTTON_PIN 6
#define KEY6_LED_PIN 19
#define KEY6_SERVO_CHANNEL 7
#define KEY6_NOTE 370  // F#4

#define KEY7_BUTTON_PIN 7
#define KEY7_LED_PIN 23
#define KEY7_SERVO_CHANNEL 8
#define KEY7_NOTE 392  // G4

#define KEY8_BUTTON_PIN 8
#define KEY8_LED_PIN 26
#define KEY8_SERVO_CHANNEL 9
#define KEY8_NOTE 415  // G#4

#define KEY9_BUTTON_PIN 9
#define KEY9_LED_PIN 27
#define KEY9_SERVO_CHANNEL 10
#define KEY9_NOTE 440  // A4

#define KEY10_BUTTON_PIN 10
#define KEY10_LED_PIN 32
#define KEY10_SERVO_CHANNEL 11
#define KEY10_NOTE 466 // A#4

#define KEY11_BUTTON_PIN 11
#define KEY11_LED_PIN 33
#define KEY11_SERVO_CHANNEL 12
#define KEY11_NOTE 494 // B4

// ROYGBIV colour palette
#define COLOR_RED     0xFF0000
#define COLOR_ORANGE  0xFF8000
#define COLOR_YELLOW  0xFFFF00
#define COLOR_GREEN   0x00FF00
#define COLOR_BLUE    0x0000FF
#define COLOR_INDIGO  0x4B0082
#define COLOR_VIOLET  0x8000FF
#define COLOR_WHITE   0xFFFFFF

// ============ TYPE DEFINITIONS ============

enum Mode {
  MANUAL,         // no automatic functions, user plays manually
  GUIDED,         // LEDs light up in sequence, user must press key to advance
  TEACHING        // LEDs + servos play automatically
};

struct Key {
  int buttonPin;
  int ledPin;                  // Store pin number, NeoPixel created in setup()
  Adafruit_NeoPixel* led;      // Pointer to NeoPixel object (initialized in setup)
  int servoChannel;
  int noteFreq;
  bool isPressed;
};

struct SequenceStep {
  uint8_t keyIndex;   // Which key to activate (0 to NUM_KEYS-1)
  uint32_t color;     // LED color
  uint16_t duration;  // How long to hold (ms)
};

struct Sequence {
  int id;
  SequenceStep steps[MAX_SEQUENCE_LENGTH];
  uint8_t length;
  char name[32];
};

enum TestLogErrorCode : uint8_t {
  TESTLOG_OK = 0,
  TESTLOG_INVALID_STEP_INDEX = 1,
  TESTLOG_INVALID_KEY_INDEX = 2
};

#endif